const palette = document.getElementById('palette');
const sidebar = document.getElementById('sidebar');
const routeLinks = document.querySelectorAll('[data-route]');

function setActiveRoute(hash) {
  const target = hash || '#dashboard';
  document.querySelectorAll('.nav-item').forEach((item) => {
    item.classList.toggle('active', item.getAttribute('href') === target);
  });
}

function closePalette() {
  palette?.classList.remove('open');
  palette?.setAttribute('aria-hidden', 'true');
}

function openPalette() {
  palette?.classList.add('open');
  palette?.setAttribute('aria-hidden', 'false');
  palette?.querySelector('input')?.focus();
}

document.querySelectorAll('[data-open-palette]').forEach((node) => {
  node.addEventListener('focus', openPalette);
  node.addEventListener('click', openPalette);
});

document.querySelector('[data-mobile-menu]')?.addEventListener('click', () => {
  sidebar?.classList.toggle('open');
});

routeLinks.forEach((link) => {
  link.addEventListener('click', () => {
    const href = link.getAttribute('href');
    setActiveRoute(href);
    closePalette();
    sidebar?.classList.remove('open');
  });
});

palette?.addEventListener('click', (event) => {
  if (event.target === palette) closePalette();
});

document.addEventListener('keydown', (event) => {
  const key = event.key.toLowerCase();
  if ((event.ctrlKey || event.metaKey) && key === 'k') {
    event.preventDefault();
    openPalette();
  }
  if (event.key === 'Escape') {
    closePalette();
    sidebar?.classList.remove('open');
  }
});

window.addEventListener('hashchange', () => setActiveRoute(window.location.hash));
setActiveRoute(window.location.hash);
